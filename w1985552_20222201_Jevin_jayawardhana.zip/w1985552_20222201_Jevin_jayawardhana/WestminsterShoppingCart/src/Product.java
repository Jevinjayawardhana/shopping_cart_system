import java.util.ArrayList;
import java.util.List;

// Abstract Product class
abstract class Product {
    private String productId;
    private String productName;
    private int availableItems;
    private double price;

    public Product(String productId, String productName, int availableItems, double price) {
        this.productId = productId;
        this.productName = productName;
        this.availableItems = availableItems;
        this.price = price;
    }

    // Getters and setters

    public String getProductId() {
        return productId;
    }



    public String getProductName() {
        return productName;
    }



    public int getAvailableItems() {
        return availableItems;
    }



    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void decreaseAvailableItems() {

    }

    // Additional methods as needed
}