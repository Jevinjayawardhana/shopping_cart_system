package ShoppingManager;
public interface ShoppingCartFrame {
    default void setVisible(boolean b) {

    }
}
