import java.io.*;
import java.util.*;
import javax.swing.*;

class WestminsterShoppingManager implements ShoppingManager {
    private List<Product> products;

    public WestminsterShoppingManager() {
        this.products = new ArrayList<>();
    }

    // Other methods for managing the product list and system operations

    public void Menu() {

        Scanner scanner = new Scanner(System.in);
        int choose;
        do {
            System.out.println("");
            System.out.println("");
            System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
            System.out.println("||-----------WELCOME TO WESTMINSTER SHOPPING CART-------------||");
            System.out.println("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
            System.out.println("||  1. ADD NEW PRODUCT                                        ||");
            System.out.println("||  2. DELETE A PRODUCT                                       ||");
            System.out.println("||  3. PRINT THE LIST OF PRODUCT                              ||");
            System.out.println("||  4. SAVE THE DETAILS TO THE FILE                           ||");
            System.out.println("||  5. GUI                                                    ||");
            System.out.println("||  6. EXIT                                                   ||");
            System.out.println("ENTER YOUR CHOICE     :                                         ");
            System.out.println("");
            System.out.println("");
            choose = scanner.nextInt();

            switch (choose) {
                case 1:
                    ShoppingCartGUI r = new ShoppingCartGUI();
                    ProductAdding();
                    break;
                case 2:
                    ProductDelete();
                    break;
                case 3:
                    ProductPrinting();
                    break;
                case 4:
                    SavingFile();
                    break;

                case 6:
                    // Load ShoppingCartGUI
                    loadShoppingCartGUI();
                    break;
                case 0:
                    System.out.println("Exiting Westminster Shopping Manager. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
                    break;
            }
        } while (choose != 0);
    }

    private void ProductAdding() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("ADD PRODUCT:");
        System.out.println("1. ElECTRONICS");
        System.out.println("2. CLOTHING");
        System.out.print("Choose product type (1 or 2): ");

        int productchoose = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String Id, productName;
        int availableItems;
        double price;

        switch (productchoose) {
            case 1:
                // Add Electronics
                System.out.print("ENTER THE BRAND: ");
                String brand = scanner.nextLine();
                System.out.print("WARRANTY PERIOD(MONTH): ");
                int warrantyPeriod = scanner.nextInt();

                while (true) {
                    System.out.print("PRODUCT ID: ");
                    Id = scanner.next();
                    if (isProductIdExists(Id)) {
                        System.out.println("PRODUCT ID ALREADY EXIST.TRY AGAIN");
                    } else {
                        break;
                    }
                }

                System.out.print("PRODUCT NAME: ");
                productName = scanner.next();
                System.out.print("ENTER QUANTITY: ");
                availableItems = scanner.nextInt();
                System.out.print("ENTER PRICE: ");
                price = scanner.nextDouble();

                // Create and add Electronics to the product list
                ElectronicsCart electronics = new ElectronicsCart(Id, productName, price, brand, warrantyPeriod);
                products.add(electronics);

                System.out.println("ELECTRONIC ITEM ADDED SUCCESSFULLY");
                break;

            case 2:
                // Add Clothing
                System.out.print("ENTER THE SIZE: ");
                String size = scanner.next();
                System.out.print("ENTER THE COLOUR: ");
                String color = scanner.next();

                System.out.print("ENTER THE ID: ");
                Id = scanner.next();
                System.out.print("PRODUCT NAME: ");
                productName = scanner.next();
                System.out.print("ENTER QUANTITY: ");
                availableItems = scanner.nextInt();
                System.out.print("ENTER PRICE: ");
                price = scanner.nextDouble();

                // Create and add Clothing to the product list
                ClothingCart clothing = new ClothingCart(Id, productName, price, size, color);
                products.add(clothing);

                System.out.println("CLOTHING ITEM SUCCESSFULLY ADDED.");
                break;

            default:
                System.out.println("INVALID CHOICE");
                break;
        }
    }

    private boolean isProductIdExists(String productId) {
        for (Product product : products) {
            if (product.getProductId().equals(productId)) {
                return true; // Product ID already exists
            }
        }
        return false; // Product ID does not exist
    }


    private void ProductDelete() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("ENTER THE ID OF THE PRODUCT THAT YOU WANT TO DELETE: ");
        String productIdToDelete = scanner.next();

        // Search for the product with the given ID
        Product productToDelete = null;
        for (Product product : products) {
            if (product.getProductId().equals(productIdToDelete)) {
                productToDelete = product;
                break;
            }
        }

        if (productToDelete != null) {
            // Display information about the product being deleted
            System.out.println("DELETING PRODUCT:");
            System.out.println(productToString(productToDelete));

            // Remove the product from the list
            products.remove(productToDelete);

            System.out.println("PRODUCT DELETED SUCCESSFULLY.");
        } else {
            System.out.println("PRODUCT ID '" + productIdToDelete + "' IS NOT FOUND.");
        }
    }


    private void ProductPrinting() {
        // Implement logic to print the list of products in alphabetical order based on the product ID
        Collections.sort(products, Comparator.comparing(Product::getProductId));

        for (Product product : products) {
            System.out.println(productToString(product));
        }
    }

    private void SavingFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("Westminster_shopping.csv"))) {
            // Write header
            writer.println("ProductID,ProductName,AvailableItems,Price,Type,Brand,WarrantyPeriod,Size,Color");

            // Write each product
            for (Product product : products) {
                if (product instanceof ElectronicsCart) {
                    writer.println(product.getProductId() + ","
                            + product.getProductName() + "," +
                            product.getAvailableItems() + ","
                            + product.getPrice() + ",Electronics," +
                            ((ElectronicsCart) product).getBrand() + ","
                            + ((ElectronicsCart) product).getWarrantyPeriod());
                } else if (product instanceof ClothingCart) {
                    writer.println(product.getProductId() + ","
                            + product.getProductName() + "," +
                            product.getAvailableItems() + ","
                            + product.getPrice() + ",Clothing," + "," + "," +
                            ((ClothingCart) product).getSize() + ","
                            + ((ClothingCart) product).getColor());
                }
            }

            System.out.println("PRODUCT SAVE SUCCESSFULLY.");
        } catch (IOException e) {
            System.err.println("ERROR: " + e.getMessage());
        }
    }


    private String productToString(Product product) {
        if (product instanceof ElectronicsCart) {
            return "Electronics: " + product.getProductId() + " - " + product.getProductName() +
                    " (Brand: " + ((ElectronicsCart) product).getBrand() + ", Warranty: " + ((ElectronicsCart) product).getWarrantyPeriod() + ")";
        } else if (product instanceof ClothingCart) {
            return "Clothing: " + product.getProductId() + " - " + product.getProductName() +
                    " (Size: " + ((ClothingCart) product).getSize() + ", Color: " + ((ClothingCart) product).getColor() + ")";
        } else {
            return "Unknown Product Type";
        }
    }

    private static void loadShoppingCartGUI() {
        SwingUtilities.invokeLater(() -> {
            ShoppingCartGUI shoppingCartGUI = new ShoppingCartGUI();
            shoppingCartGUI.setSize(800, 600);
            shoppingCartGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            shoppingCartGUI.setVisible(true);
        });
    }
}


