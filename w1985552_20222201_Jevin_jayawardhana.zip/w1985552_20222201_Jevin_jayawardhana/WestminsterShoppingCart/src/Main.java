//calling the main method
public class Main {
    public static void main(String[] args) {
        WestminsterShoppingManager manager = new WestminsterShoppingManager();
        manager.Menu();
    }
}

